#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 20:39:12 2022

@author: petertian
"""

import pandas as pd

path = '/Users/petertian/Desktop/文件/Vanderbilt/semester 3/Machine Learning 2/ML_Project_Transpotation_Rate/TransRater/sample data'
data = pd.read_csv(path + '/1.csv')